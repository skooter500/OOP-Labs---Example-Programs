﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication6
{
    public class BiPed:Animal
    {
        public BiPed()
        {
            numLegs = 2;
        }
    }
}
