﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication6
{
    // A Human IS A Biped
    // A human EXTENDS the biPed
    public class Human:BiPed
    {
    }
}
